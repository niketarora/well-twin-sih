---
name: Well Twin Subsurface Intelligence
colors:
  surface: '#f7f9ff'
  surface-dim: '#d1dbe9'
  surface-bright: '#f7f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#edf4ff'
  surface-container: '#e4effd'
  surface-container-high: '#dfe9f7'
  surface-container-highest: '#d9e3f1'
  on-surface: '#121c26'
  on-surface-variant: '#4e4637'
  inverse-surface: '#27313c'
  inverse-on-surface: '#e8f2ff'
  outline: '#807665'
  outline-variant: '#d2c5b2'
  surface-tint: '#7c5801'
  primary: '#7c5801'
  on-primary: '#ffffff'
  primary-container: '#c69a45'
  on-primary-container: '#4b3400'
  inverse-primary: '#efbf66'
  secondary: '#166395'
  on-secondary: '#ffffff'
  secondary-container: '#89c7ff'
  on-secondary-container: '#005381'
  tertiary: '#006d3d'
  on-tertiary: '#ffffff'
  tertiary-container: '#4eb478'
  on-tertiary-container: '#004122'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdea7'
  primary-fixed-dim: '#efbf66'
  on-primary-fixed: '#271900'
  on-primary-fixed-variant: '#5e4200'
  secondary-fixed: '#cde5ff'
  secondary-fixed-dim: '#95ccff'
  on-secondary-fixed: '#001d32'
  on-secondary-fixed-variant: '#004a75'
  tertiary-fixed: '#91f8b5'
  tertiary-fixed-dim: '#75db9b'
  on-tertiary-fixed: '#00210f'
  on-tertiary-fixed-variant: '#00522d'
  background: '#f7f9ff'
  on-background: '#121c26'
  surface-variant: '#d9e3f1'
typography:
  headline-xl:
    fontFamily: IBM Plex Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: IBM Plex Sans
    fontSize: 26px
    fontWeight: '600'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: IBM Plex Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: IBM Plex Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  headline-sm:
    fontFamily: IBM Plex Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  telemetry-data:
    fontFamily: JetBrains Mono
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 24px
    letterSpacing: -0.02em
  telemetry-unit:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  gutter-compact: 0.75rem
  gutter-default: 1rem
  gutter-spacious: 1.5rem
---

## Brand & Style

This design system serves petroleum engineers, field geologists, and remote operations teams managing thermal recovery and production telemetry across the Baghewala heavy oil field. The core design philosophy balances industrial precision with cognitive calm. It replaces the cluttered, dark-mode SCADA aesthetic of legacy industrial systems with a bright, crisp, paper-like clarity optimized for sustained analytical focus over extended operational shifts.

The design movement is **Technical Minimalism**: disciplined spatial distribution, structured typography, purposeful micro-interactions, and calibrated contrast tiers. Surfaces mimic premium drafting paper and clean hardware monitors. Visual weight is strictly derived from operational criticalities—normal states blend serenely into the background, while operational anomalies and thermal phase shifts immediately command visual priority.

## Colors

The palette establishes an authoritative, high-legibility interface anchored in geology and metallurgy:

- **Canvas & Surfaces:**
  - Base canvas: `#F4F6F8` (Calibrated field-slate grey that prevents eye fatigue).
  - Primary surface: `#FFFFFF` (Dedicated card/container background for maximum contrast).
  - Secondary surface: `#F8F9FA` (Sub-panels, table headers, and telemetry readouts).
  - Structural borders: `#E2E6EA` (Crisp hairline dividers for architectural segmentation).

- **Typography & Tonal Contrast:**
  - Primary text: `#17212B` (Deep petroleum slate, high legibility without harsh absolute black).
  - Secondary text: `#66717C` (Metadata, units, and static system labels).
  - Muted text: `#8B949E` (Disabled states, inactive axes, and watermark IDs).

- **Brand Accent:**
  - Petroleum Amber: `#C69A45` (Represents extracted crude and system highlight targets; applied sparingly to active operational filters, pipeline traces, and primary callouts).

- **Semantic Engineering States:**
  - Normal / Stable: `#3FA66B` (Optimal wellhead pressure, pump stroke consistency).
  - Advisory / Warning: `#D49A3A` (Viscosity thresholds, thermal loss alerts).
  - Critical / Trip: `#D95C5C` (Borehole pressure divergence, emergency shutdown indicators).
  - Information / Telemetry: `#4F8FC4` (Subsea/downhole acoustic sensors, flow metrics).

## Typography

Typography enforces a strict hierarchy tailored for dense industrial supervision:

1. **Section Titles & Rig Identifiers (IBM Plex Sans):** Provides an architectural, grounded demeanor. Semi-bold weights guarantee quick identification of borehole tags and sector locations.
2. **Operational Text & Reports (Inter):** Maximizes readability in tabular arrays, parameter trees, and real-time event logs.
3. **Sensor Metrics & Numerical Data (JetBrains Mono / Monospace):** Guarantees zero horizontal jitter across real-time updates (e.g., dynamic casing pressure, steam-to-oil ratio, downhole temperature). Tabular numbers must remain vertically aligned across high-frequency metric feeds.

## Layout & Spacing

This design system uses a strict **8px baseline grid** configured as a 12-column fluid system within operational dashboards:

- **Desktop (≥ 1440px):** 12 columns, 16px (`1rem`) gutters, 24px (`1.5rem`) outer canvas margins. Multi-column arrangements hold 3D digital twins, log curves, and wellhead telemetry simultaneously.
- **Laptop / Operations Tablet (1024px – 1439px):** 8 columns, 12px (`0.75rem`) gutters, 16px margins. Telemetry panels stack or dock into collapsible side rails.
- **Field Terminal / Mobile (< 1024px):** 4 columns, 8px (`0.5rem`) gutters, 12px margins. Gauges and metrics collapse into single-column vertical cards.

Component padding adheres strictly to the operational density scale:
- High-density data tables: 8px vertical padding per row.
- Telemetry summary cards: 16px internal padding.
- Top-level operational zones: 24px structural gap.

## Elevation & Depth

Visual depth is achieved through **structural planar layering and low-contrast outlines** rather than heavy blurred drop shadows. This preserves daylight readability in field conditions and keeps the UI calm:

- **Level 0 (Canvas Base):** `#F4F6F8`. The grounding backdrop for all workspace layouts.
- **Level 1 (Card & Module Containers):** `#FFFFFF` with a crisp 1px solid border (`#E2E6EA`) and no drop shadow.
- **Level 2 (Active Gauges & Hover Panels):** `#FFFFFF` with border `#D1D7DC` and subtle ambient diffusion: `0 2px 4px rgba(23, 33, 43, 0.04), 0 1px 2px rgba(23, 33, 43, 0.02)`.
- **Level 3 (Diagnostic Flyouts & Popovers):** `#FFFFFF` bordered by `#C69A45` (40% opacity) or `#E2E6EA`, elevated with an amber-calibrated shadow: `0 8px 24px rgba(23, 33, 43, 0.08), 0 2px 6px rgba(198, 154, 69, 0.06)`.
- **Level 4 (Emergency Modal Alerts & Overrides):** `#FFFFFF` with a 1px border of `#D95C5C` and high-elevation shadow: `0 16px 32px rgba(23, 33, 43, 0.16)`.

## Shapes

The interface balances industrial precision with modern ergonomics:

- **Standard Cards and Panels:** Fixed at `8px` to `12px` border radius (`roundedness: 2`). This keeps the visual geometry sharp without feeling severe.
- **Telemetry Chips and Sensor Status Badges:** `4px` to `6px` radius to maintain a structural, instrumentation-inspired quality.
- **Action Controls (Buttons, Form Inputs):** `8px` corner radius.
- **Never Use Pill Radii for Technical UI:** Full round/pill buttons (`rounded-full`) are prohibited for critical telemetry and operational controls to preserve engineering discipline.

## Components

### Buttons
- **Primary Operational:** Background `#C69A45`, text `#FFFFFF`, font weight 600. Border radius 8px. Hover: `#B58B3A`. Active: `#9E772E`.
- **Secondary (Data Actions):** Background `#FFFFFF`, border 1px solid `#E2E6EA`, text `#17212B`. Hover: background `#F8F9FA`, border `#D1D7DC`.
- **Destructive (Wellhead Trip/Emergency Shutdown):** Background `#D95C5C`, text `#FFFFFF`. Hover: `#C24C4C`. Includes mandatory two-step confirmation state.

### Telemetry Cards & Metric Blocks
- Background `#FFFFFF`, 1px solid border `#E2E6EA`, 12px border radius.
- Headers feature the parameter name in `Inter Medium 12px` (`#66717C`) in uppercase with 0.04em letter spacing.
- Numerical readouts use `JetBrains Mono 18px` (`#17212B`), followed immediately by inline units (`psi`, `bpd`, `°C`) in `#8B949E`.

### Status Indicators & Badges
- Compact rectangular badges (4px radius) with a 2px left border matching the semantic health state:
  - **Healthy:** Background `rgba(63, 166, 107, 0.08)`, border/text `#3FA66B`.
  - **Warning:** Background `rgba(212, 154, 58, 0.08)`, border/text `#D49A3A`.
  - **Critical:** Background `rgba(217, 92, 92, 0.08)`, border/text `#D95C5C`.
  - **Info:** Background `rgba(79, 143, 196, 0.08)`, border/text `#4F8FC4`.

### Data Tables & Log Feeds
- Zebra alternating backgrounds strictly avoided. Header row `#F8F9FA` with 1px bottom border `#E2E6EA`.
- Row height fixed at 36px for dense views and 44px for default views. Hover row state uses `#F4F6F8`.
- Numerical columns right-aligned and rendered in monospaced font.

### Form Inputs & Well Parameter Controls
- Height 36px. Background `#FFFFFF`, 1px solid `#E2E6EA`, border radius 6px.
- Focus state: 1px outline in `#C69A45` with ambient glow `0 0 0 3px rgba(198, 154, 69, 0.15)`.

### Wellbore Cross-Section / 3D Canvas Overlay
- Floating semi-transparent HUD panels: background `rgba(255, 255, 255, 0.92)` with `backdrop-filter: blur(8px)`, 1px border `#E2E6EA`.