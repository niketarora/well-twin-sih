import json
import joblib
import pandas as pd
import torch
import torch.nn as nn


MODEL_FILE = r".\models\srp_autoencoder.pt"
SCALER_FILE = r".\models\scaler.pkl"
PREPROCESS_FILE = r".\models\preprocessing.json"
THRESHOLD_FILE = r".\models\threshold.json"


FEATURES = [
    "SPM",
    "pump_fillage",
    "min_rod_weight",
    "max_rod_weight",
    "dynamometer_area",
    "rod_load_range"
]


class SRPAutoencoder(nn.Module):

    def __init__(self, input_dim):
        super().__init__()

        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 32),
            nn.ReLU(),
            nn.Linear(32, 16),
            nn.ReLU(),
            nn.Linear(16, 8)
        )

        self.decoder = nn.Sequential(
            nn.Linear(8, 16),
            nn.ReLU(),
            nn.Linear(16, 32),
            nn.ReLU(),
            nn.Linear(32, input_dim)
        )

    def forward(self, x):
        return self.decoder(self.encoder(x))


def load_model():

    device = torch.device(
        "cuda" if torch.cuda.is_available() else "cpu"
    )

    model = SRPAutoencoder(len(FEATURES)).to(device)

    model.load_state_dict(
        torch.load(
            MODEL_FILE,
            map_location=device,
            weights_only=True
        )
    )

    model.eval()

    scaler = joblib.load(SCALER_FILE)

    with open(PREPROCESS_FILE, "r") as f:
        preprocessing = json.load(f)

    with open(THRESHOLD_FILE, "r") as f:
        thresholds = json.load(f)

    return model, scaler, preprocessing, thresholds, device


def predict(
    spm,
    pump_fillage,
    min_rod_weight,
    max_rod_weight,
    dynamometer_area
):

    values = [
        spm,
        pump_fillage,
        min_rod_weight,
        max_rod_weight,
        dynamometer_area
    ]

    if any(pd.isna(value) for value in values):
        raise ValueError("All sensor values must be provided.")

    if max_rod_weight < min_rod_weight:
        raise ValueError(
            "Maximum rod weight cannot be less than minimum rod weight."
        )

    rod_load_range = max_rod_weight - min_rod_weight

    data = {
        "SPM": spm,
        "pump_fillage": pump_fillage,
        "min_rod_weight": min_rod_weight,
        "max_rod_weight": max_rod_weight,
        "dynamometer_area": dynamometer_area,
        "rod_load_range": rod_load_range
    }

    model, scaler, preprocessing, thresholds, device = load_model()

    X = pd.DataFrame(
        [data],
        columns=FEATURES
    )

    for feature in FEATURES:

        X[feature] = X[feature].clip(
            lower=preprocessing[feature]["lower"],
            upper=preprocessing[feature]["upper"]
        )

    X_scaled = scaler.transform(X)

    X_tensor = torch.tensor(
        X_scaled,
        dtype=torch.float32
    ).to(device)

    with torch.no_grad():

        reconstructed = model(X_tensor)

        anomaly_score = torch.mean(
            (X_tensor - reconstructed) ** 2,
            dim=1
        ).item()

    warning_threshold = thresholds["warning_threshold"]
    critical_threshold = thresholds["critical_threshold"]

    if anomaly_score >= critical_threshold:
        condition = "CRITICAL"

    elif anomaly_score >= warning_threshold:
        condition = "WARNING"

    else:
        condition = "NORMAL"

    return {
        "condition": condition,
        "anomaly_score": round(anomaly_score, 6),
        "warning_threshold": round(warning_threshold, 6),
        "critical_threshold": round(critical_threshold, 6)
    }


if __name__ == "__main__":

    print()
    print("=" * 60)
    print("SRP CONDITION MODEL")
    print("=" * 60)

    try:

        spm = float(input("Enter SPM: "))

        pump_fillage = float(
            input("Enter Pump Fillage (%): ")
        )

        min_rod_weight = float(
            input("Enter Minimum Rod Weight: ")
        )

        max_rod_weight = float(
            input("Enter Maximum Rod Weight: ")
        )

        dynamometer_area = float(
            input("Enter Dynamometer Area: ")
        )

        result = predict(
            spm=spm,
            pump_fillage=pump_fillage,
            min_rod_weight=min_rod_weight,
            max_rod_weight=max_rod_weight,
            dynamometer_area=dynamometer_area
        )

        print()
        print("=" * 60)
        print("SRP CONDITION RESULT")
        print("=" * 60)

        print(
            "Condition       :",
            result["condition"]
        )

        print(
            "Anomaly Score   :",
            result["anomaly_score"]
        )

        print(
            "Warning Level   :",
            result["warning_threshold"]
        )

        print(
            "Critical Level  :",
            result["critical_threshold"]
        )

        print("=" * 60)

    except ValueError as e:

        print()
        print("ERROR:", e)